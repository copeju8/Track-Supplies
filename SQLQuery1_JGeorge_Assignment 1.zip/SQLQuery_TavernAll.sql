CREATE TABLE TavernALL (
TavernAllID int NOT NULL IDENTITY (301,1) PRIMARY KEY,
TavernName varchar(255),
TavernLocationID varchar(20),
TavernOwnerID varchar(20));
