CREATE TABLE TavernService (
TavernServiceID int NOT NULL IDENTITY (1001,1) PRIMARY KEY,
	ServiceType varchar(100),
	ServiceItem# varchar(100),
	ServiceItemDescription varchar(255),
	ServiceUOM varchar(100),
	ServiceUnitCost INT, 
	ServiceStatus varchar(100)
);