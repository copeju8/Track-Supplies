CREATE TABLE TavernGuest (
TavernGuestID int NOT NULL IDENTITY (1,1) PRIMARY KEY,
TavernGuestName varchar(255));
