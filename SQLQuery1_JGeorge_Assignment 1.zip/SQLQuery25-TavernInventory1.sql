CREATE TABLE TavernInventory (
TavernInventoryID INT NOT NULL IDENTITY (801,1) PRIMARY KEY,
	TavernLocationID INT NOT NULL REFERENCES TavernLocation(TavernLocationID),
	InventoryDate DATE,
	InventoryBegn INT,
	
	);