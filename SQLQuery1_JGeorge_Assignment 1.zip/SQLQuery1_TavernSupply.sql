CREATE TABLE TavernSupply (
TavernSupplyID int NOT NULL IDENTITY (401,1) PRIMARY KEY,
	SupplyType varchar(100),
	SupplyItem# varchar(100),
	SupplyItemDescription varchar(255),
	SupplyUOM varchar(100),
	SupplyUnitCost INT, 
	SupplyStatus varchar(100)
);