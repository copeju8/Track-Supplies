select * from TavernService
