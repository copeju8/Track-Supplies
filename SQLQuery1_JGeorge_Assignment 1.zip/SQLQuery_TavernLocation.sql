
CREATE TABLE TavernLocation (
ID int NOT NULL IDENTITY (201,1) PRIMARY KEY,
TavernLocationID varchar(20),
TavernLocationName varchar(255));