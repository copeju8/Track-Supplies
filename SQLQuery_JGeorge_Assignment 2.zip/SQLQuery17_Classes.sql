CREATE TABLE Classes (
ClassesID int NOT NULL IDENTITY (1,1) PRIMARY KEY,
Name varchar(100)
);
