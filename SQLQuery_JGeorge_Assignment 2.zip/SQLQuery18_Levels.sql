CREATE TABLE Level (
	LevelID INT Primary Key IDENTITY(1, 1),
	ClassesID INT NOT NULL REFERENCES Classes(ClassesID),
	TavernGuestID INT NOT NULL REFERENCES TavernGuest(TavernGuestID),
	LevelDate DATE,
);