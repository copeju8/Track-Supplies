CREATE TABLE SuppliesSales (
SuppliesSalesID int NOT NULL IDENTITY (1,1) PRIMARY KEY,
	TavernAllID INT NOT NULL REFERENCES TavernAll(TavernAllID),
	TavernGuestID INT NOT NULL REFERENCES TavernGuest(TavernGuestID),
	TavernSupplyID INT NOT NULL REFERENCES TavernSupply(TavernSupplyID),
	SupplySalesPriceUC Decimal(10,2), 
	QTYPurchased INT,
	SuppliesInvoice# varchar(100),
	SalesDate DATE,
	);