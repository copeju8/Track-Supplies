CREATE TABLE TavernGuest (
TavernGuestID int NOT NULL IDENTITY (11,1) PRIMARY KEY,
Name varchar(100), 
Notes varchar(Max),
Birthdate varchar(100),
GuestStatus varchar(255),
TavernGuestStatusID INT NOT NULL REFERENCES TavernGuestStatus(TavernGuestStatusID)
);

