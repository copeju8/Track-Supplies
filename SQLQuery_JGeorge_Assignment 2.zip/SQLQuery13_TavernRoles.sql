CREATE TABLE TavernRoles (
TavernRolesID int NOT NULL IDENTITY (1,1) PRIMARY KEY,
Name varchar(100),
Description varchar(255),
);