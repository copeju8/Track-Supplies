CREATE TABLE Tavern (
TavernOwnerID int NOT NULL IDENTITY (101,1) PRIMARY KEY,
TavernOwnerName varchar(255));

