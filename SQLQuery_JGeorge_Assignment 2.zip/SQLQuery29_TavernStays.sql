CREATE TABLE TavernStays (
TavernStaysID int NOT NULL IDENTITY (1,1) PRIMARY KEY,
SuppliesSalesID INT NOT NULL REFERENCES SuppliesSales(SuppliesSalesID),
TavernGuestID INT NOT NULL REFERENCES TavernGuest(TavernGuestID),
TavernRoomID INT NOT NULL REFERENCES TavernRoom(TavernRoomID),
TavernDate DATE
);
