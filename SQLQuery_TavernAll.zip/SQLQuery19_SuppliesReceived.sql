CREATE TABLE SuppliesReceived (
SuppliesReceivedID int NOT NULL IDENTITY (601,1) PRIMARY KEY,
	TavernLocationID INT,
	TavernSupplyID INT,
	TavernSupplierID INT,
	SupplyUOM varchar(100),
	SupplyReceivedUnitCost Decimal(10,2), 
	QTYReceived INT,
	ReceivedTC INT,
	);