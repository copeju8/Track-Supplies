CREATE TABLE TavernInventoryOH (
InventoryOHID INT NOT NULL IDENTITY (901,1) PRIMARY KEY,
	TavernInventoryID INT NOT NULL REFERENCES TavernInventory1(TavernInventoryID),
	SuppliesReceivedID INT NOT NULL REFERENCES SuppliesReceived(SuppliesReceivedID),
	SuppliesSalesID INT NOT NULL REFERENCES SuppliesSales(SuppliesSalesID),
	EndingInventory INT, 
	InventoryOHDate DATE,
	);