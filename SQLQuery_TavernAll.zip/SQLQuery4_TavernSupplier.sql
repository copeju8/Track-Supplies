CREATE TABLE TavernSupplier (
TavernSupplierID int NOT NULL IDENTITY (501,1) PRIMARY KEY,
TavernSupplierName varchar(255));
